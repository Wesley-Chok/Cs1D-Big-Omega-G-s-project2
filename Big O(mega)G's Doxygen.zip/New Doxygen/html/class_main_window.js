var class_main_window =
[
    [ "MainWindow", "class_main_window.html#a3443effb4be4d7df15f6e71db649cfb9", null ],
    [ "~MainWindow", "class_main_window.html#ae98d00a93bc118200eeef9f9bba1dba7", null ]
];