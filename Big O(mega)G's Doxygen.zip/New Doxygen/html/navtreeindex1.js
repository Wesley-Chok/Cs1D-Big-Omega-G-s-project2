var NAVTREEINDEX1 =
{
"graph_8h_source.html":[1,0,0,0,2],
"hierarchy.html":[0,2],
"index.html":[],
"mainwindow_8h_source.html":[1,0,0,0,3],
"pages.html":[],
"stadiumdis_8h_source.html":[1,0,0,0,5],
"team_8h_source.html":[1,0,0,0,6],
"ui__mainwindow_8h_source.html":[1,0,0,0,7]
};
