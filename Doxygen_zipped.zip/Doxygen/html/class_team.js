var class_team =
[
    [ "Team", "class_team.html#a112d778e85a66d9068a1fc9f0ed5648e", null ],
    [ "getBallparkTypology", "class_team.html#a8489a49916b7e6cd4d1f5be5c1c40a61", null ],
    [ "getDateOpened", "class_team.html#a74aa6dccc33527924c3c02a59cfaca7d", null ],
    [ "getDTC", "class_team.html#a4a85fe4655fdeee5c182d55a8caad168", null ],
    [ "getLeague", "class_team.html#ab84752905957d1975d782b205ca5fcce", null ],
    [ "getLocation", "class_team.html#a635cc8f899f0728860566ae62a92dfbc", null ],
    [ "getPlayingSurface", "class_team.html#ad8129026d7829e247b76bc3faaade523", null ],
    [ "getroofType", "class_team.html#a5fa2241df0b6d1ba42639134472d16d9", null ],
    [ "getSeatingCapacity", "class_team.html#a43053fe34523ff77bb279b3bb5d8bd2d", null ],
    [ "getStadiumName", "class_team.html#af18fa6f151736eaefe455b74972f3266", null ],
    [ "getTeamName", "class_team.html#a27c9ba105e4d267f3053621d18706bd8", null ],
    [ "setBallparkTypology", "class_team.html#a520051c030ff5425ec57d8f3a321bb86", null ],
    [ "setDateOpened", "class_team.html#ad6a4334e915d71d92eae35a95cd3ddb8", null ],
    [ "setDTC", "class_team.html#a1f288d750fe7b8d99954f4acd32ff8a7", null ],
    [ "setLeague", "class_team.html#a4ad25a7c23ae00458827fbf5bfc76672", null ],
    [ "setLocation", "class_team.html#aea0db2d37e08d078f2646e5445e9cf00", null ],
    [ "setPlayingSurface", "class_team.html#ac7b78a1332f3ee50f15efa75a4d862a8", null ],
    [ "setRoofType", "class_team.html#a62009ffac352a7f3d9d3fdca8a921c97", null ],
    [ "setSeatingCapacity", "class_team.html#a84548f7aa1cd5389add25acd2c62614c", null ],
    [ "setStadiumName", "class_team.html#afc2fa27530fd55e9dc6d415cfb06805b", null ],
    [ "setTeamName", "class_team.html#a90c50fea538bff1d1ff46a090ceab75e", null ]
];