var annotated_dup =
[
    [ "Ui", null, [
      [ "MainWindow", "class_ui_1_1_main_window.html", null ]
    ] ],
    [ "Admin", "class_admin.html", "class_admin" ],
    [ "Controller", "class_controller.html", "class_controller" ],
    [ "graph", "classgraph.html", "classgraph" ],
    [ "Hash", "class_hash.html", "class_hash" ],
    [ "MainWindow", "class_main_window.html", "class_main_window" ],
    [ "Souvenir", "class_souvenir.html", "class_souvenir" ],
    [ "stadiumdis", "classstadiumdis.html", "classstadiumdis" ],
    [ "Team", "class_team.html", "class_team" ],
    [ "Ui_MainWindow", "class_ui___main_window.html", "class_ui___main_window" ]
];