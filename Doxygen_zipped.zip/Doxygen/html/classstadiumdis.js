var classstadiumdis =
[
    [ "stadiumdis", "classstadiumdis.html#a5b9ec7044fde6f59f3ea32a04cfa4554", null ],
    [ "getDistance", "classstadiumdis.html#a5085be50a56e04c37d8634f1e0764ba8", null ],
    [ "getStadium1", "classstadiumdis.html#ac0a66de854fb71e20ae9fa63e0b90459", null ],
    [ "getStadium2", "classstadiumdis.html#a7c4fdffcc2ee3ce53cb142c0813f58e2", null ],
    [ "setDistance", "classstadiumdis.html#a00abcf1530716d527242fee210bfcdb9", null ],
    [ "setStadium1", "classstadiumdis.html#ae1b2cf532d4903c72b0312064894fcb8", null ],
    [ "setStadium2", "classstadiumdis.html#a3570c9e64b7caf8247f36eaae2318204", null ]
];