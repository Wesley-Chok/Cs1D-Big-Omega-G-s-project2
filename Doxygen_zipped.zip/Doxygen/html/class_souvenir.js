var class_souvenir =
[
    [ "Souvenir", "class_souvenir.html#a5841f7bb1bc5c4c8770e5453f2b5852f", null ],
    [ "item", "class_souvenir.html#aa39ef5ca85ba08dce09bc7cba4062926", null ],
    [ "price", "class_souvenir.html#afe558dcd290082ef32ccf05919cd1ecf", null ],
    [ "setItem", "class_souvenir.html#a4e6f80287a47dd8df4275e3b8e101c72", null ],
    [ "setPrice", "class_souvenir.html#ab6947bd0e109f8e71371e20bf7c0c110", null ],
    [ "setTeam", "class_souvenir.html#a1a950fb053353f89eb53def73e0af7c6", null ],
    [ "team", "class_souvenir.html#a34301bd23da0126fd9f20cdc34468800", null ]
];