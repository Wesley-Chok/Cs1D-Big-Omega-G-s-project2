var searchData=
[
  ['team_88',['Team',['../class_team.html',1,'Team'],['../class_souvenir.html#a34301bd23da0126fd9f20cdc34468800',1,'Souvenir::team()']]]
];
