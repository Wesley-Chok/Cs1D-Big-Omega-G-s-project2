var searchData=
[
  ['mainwindow_98',['MainWindow',['../class_ui_1_1_main_window.html',1,'Ui::MainWindow'],['../class_main_window.html',1,'MainWindow']]]
];
