var searchData=
[
  ['nextstadium_152',['nextStadium',['../class_main_window.html#ab2645bc243e00c8548318c0b44f35efc',1,'MainWindow']]]
];
