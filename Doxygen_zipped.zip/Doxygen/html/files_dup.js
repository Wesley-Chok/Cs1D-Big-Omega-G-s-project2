var files_dup =
[
    [ "Cs1D-Big-Omega-G-s-project2-daniel_branch", "dir_ff1ef43b55ad0474bcabc692631da1e9.html", "dir_ff1ef43b55ad0474bcabc692631da1e9" ]
];