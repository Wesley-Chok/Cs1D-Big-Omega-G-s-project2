var files_dup =
[
    [ "Cs1D-Big-Omega-G-s-project2-master", "dir_fcaeb425927bbcc8b3ab9a3b178ab01c.html", "dir_fcaeb425927bbcc8b3ab9a3b178ab01c" ]
];