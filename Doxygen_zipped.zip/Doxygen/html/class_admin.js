var class_admin =
[
    [ "Admin", "class_admin.html#ae5c985f5c4fd8f407c1f2e5dda03a6a0", null ],
    [ "password", "class_admin.html#a85cfc343c683c51b3bba56ce4e6a45de", null ],
    [ "passwordChanged", "class_admin.html#a94bad89923c648e46d73a79fa4fead44", null ],
    [ "rank", "class_admin.html#a6650e3169ed66b1a61b69e5ad3e76f21", null ],
    [ "rankChanged", "class_admin.html#aa537a3552b8a00798d2f367ab3e1a9d5", null ],
    [ "setPassword", "class_admin.html#aa3fce4e0efd0eeff270234be7d52a6ea", null ],
    [ "setRank", "class_admin.html#a9047fcb109fd6d665a57b43976459e61", null ],
    [ "setUsername", "class_admin.html#a7ab5c839683fc809bdf2e899a7a892e4", null ],
    [ "username", "class_admin.html#a1cc2472ae126ca7842b84c897edbfa2d", null ],
    [ "usernameChanged", "class_admin.html#a63f71a9efa1d99948e65904ef787fb0f", null ]
];