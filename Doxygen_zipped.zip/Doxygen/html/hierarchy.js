var hierarchy =
[
    [ "Hash", "class_hash.html", null ],
    [ "QMainWindow", null, [
      [ "MainWindow", "class_main_window.html", null ]
    ] ],
    [ "QObject", null, [
      [ "Admin", "class_admin.html", null ],
      [ "Controller", "class_controller.html", null ],
      [ "graph", "classgraph.html", null ],
      [ "Souvenir", "class_souvenir.html", null ],
      [ "stadiumdis", "classstadiumdis.html", null ],
      [ "Team", "class_team.html", null ]
    ] ],
    [ "Ui_MainWindow", "class_ui___main_window.html", [
      [ "Ui::MainWindow", "class_ui_1_1_main_window.html", null ]
    ] ]
];